#!/usr/bin/env python3
"""
jsonl_to_csv_xlsx.py

Convert one or more .jsonl files (one JSON object per line) into:
- CSV (flat columns)
- Excel (.xlsx)

Features:
- Flattens nested objects into dot-separated columns (e.g., user.id, http.status)
- Safely stringifies lists/dicts that remain in cells (so CSV/Excel won't break)
- Handles multiple input files
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

import pandas as pd


def read_jsonl(path: Path) -> Tuple[List[Dict[str, Any]], int]:
    records: List[Dict[str, Any]] = []
    bad = 0

    with path.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    records.append(obj)
                else:
                    # If a line is valid JSON but not an object, wrap it.
                    records.append({"_value": obj})
            except json.JSONDecodeError:
                bad += 1

    return records, bad


def stringify_complex_cells(df: pd.DataFrame) -> pd.DataFrame:
    # Turn any remaining list/dict cells into JSON strings for CSV/Excel friendliness.
    def fix(v: Any) -> Any:
        if isinstance(v, (dict, list)):
            return json.dumps(v, ensure_ascii=False)
        return v

    for col in df.columns:
        if df[col].dtype == "object":
            df[col] = df[col].map(fix)
    return df


def convert_one(
        in_path: Path,
        out_dir: Path,
        write_csv: bool,
        write_xlsx: bool,
        excel_engine: str = "openpyxl",
) -> None:
    records, bad = read_jsonl(in_path)
    if not records:
        print(f"[skip] {in_path.name}: no valid JSON objects found (bad lines: {bad})")
        return

    df = pd.json_normalize(records, sep=".")
    df = stringify_complex_cells(df)

    base = in_path.stem  # file.jsonl -> file
    if write_csv:
        csv_path = out_dir / f"{base}.csv"
        df.to_csv(csv_path, index=False, encoding="utf-8-sig")  # Excel-friendly UTF-8
        print(f"[ok]  wrote CSV:  {csv_path}")

    if write_xlsx:
        xlsx_path = out_dir / f"{base}.xlsx"
        with pd.ExcelWriter(xlsx_path, engine=excel_engine) as writer:
            df.to_excel(writer, index=False, sheet_name="data")
        print(f"[ok]  wrote XLSX: {xlsx_path}")

    if bad:
        print(f"[warn] {in_path.name}: skipped {bad} malformed JSON lines")


def convert_combined_workbook(
        inputs: List[Path],
        out_path: Path,
        excel_engine: str = "openpyxl",
) -> None:
    with pd.ExcelWriter(out_path, engine=excel_engine) as writer:
        any_written = False
        for p in inputs:
            records, bad = read_jsonl(p)
            if not records:
                print(f"[skip] {p.name}: no valid JSON objects found (bad lines: {bad})")
                continue
            df = pd.json_normalize(records, sep=".")
            df = stringify_complex_cells(df)

            # Excel sheet name limit is 31 chars
            sheet = p.stem[:31] or "data"
            df.to_excel(writer, index=False, sheet_name=sheet)
            any_written = True

            if bad:
                print(f"[warn] {p.name}: skipped {bad} malformed JSON lines")

    if any_written:
        print(f"[ok]  wrote combined XLSX: {out_path}")
    else:
        print(f"[skip] no sheets written; combined workbook not created: {out_path}")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Convert JSONL files to CSV and/or Excel (.xlsx)."
    )
    ap.add_argument(
        "inputs",
        nargs="+",
        help="Input .jsonl file(s). You can pass multiple files.",
    )
    ap.add_argument(
        "-o",
        "--out",
        default="out",
        help="Output directory (default: ./out)",
    )
    ap.add_argument(
        "--csv",
        action="store_true",
        help="Write CSV output",
    )
    ap.add_argument(
        "--xlsx",
        action="store_true",
        help="Write Excel (.xlsx) output",
    )
    ap.add_argument(
        "--combine-xlsx",
        metavar="FILE.xlsx",
        help="Write one combined Excel workbook with each input as a sheet",
    )

    args = ap.parse_args()
    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    inputs = [Path(p).expanduser().resolve() for p in args.inputs]

    # Default behavior: if user didn't specify formats, produce both.
    write_csv = args.csv or (not args.csv and not args.xlsx and not args.combine_xlsx)
    write_xlsx = args.xlsx or (not args.csv and not args.xlsx and not args.combine_xlsx)

    for p in inputs:
        if not p.exists():
            print(f"[skip] missing: {p}")
            continue
        convert_one(p, out_dir, write_csv=write_csv, write_xlsx=write_xlsx)

    if args.combine_xlsx:
        combined_path = Path(args.combine_xlsx)
        if not combined_path.suffix.lower() == ".xlsx":
            combined_path = combined_path.with_suffix(".xlsx")
        if not combined_path.is_absolute():
            combined_path = out_dir / combined_path
        convert_combined_workbook(inputs, combined_path)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
